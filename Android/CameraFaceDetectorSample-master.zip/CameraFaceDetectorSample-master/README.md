CameraFaceDetectorSample
========================

Android Tips #16 のサンプルアプリです。