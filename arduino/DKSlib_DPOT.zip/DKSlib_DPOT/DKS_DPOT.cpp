/*
 Copyright (c) 2017 DenshiKousakuSenka
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
 */

#include "DKS_DPOT.h"

/////////////  DPOTbase  /////////////////////
DKS::DPOT::DPOTbase::DPOTbase(void)
{
}

DKS::DPOT::DPOTbase::~DPOTbase(void)
{
}

/////////////  X9Cxxx  /////////////////////

const uint8_t DKS::DPOT::X9Cxxx::wPosMax = 99;

DKS::DPOT::X9Cxxx::X9Cxxx(const X9CxxxModel &Model):m_model(Model), wPos(0), m_cs(0), m_inc(0), m_ud(0),delta(.0f), SeriesResistance(40.0f)
{
}

DKS::DPOT::X9Cxxx::X9Cxxx(const X9CxxxModel &Model, DKS::IDigitalOut *CS, DKS::IDigitalOut *INC, DKS::IDigitalOut *UD, const bool InitialZero) :
		m_model(Model), m_cs(CS), m_inc(INC), m_ud(UD), SeriesResistance(40.0f)
{
	Init(CS, INC, UD, InitialZero);
}

DKS::DPOT::X9Cxxx::~X9Cxxx(void)
{
}

void DKS::DPOT::X9Cxxx::Init(DKS::IDigitalOut *CS, DKS::IDigitalOut *INC, DKS::IDigitalOut *UD, const bool InitialZero)
{
	m_cs=CS;
	m_inc=INC;
	m_ud=UD;

	m_cs->mode(DKS::Push_Pull, DKS::Pull_Up);
	m_inc->mode(DKS::Push_Pull, DKS::Pull_Up);
	m_ud->mode(DKS::Push_Pull, DKS::Pull_Down);
	m_cs->write(1);
	m_inc->write(1);
	m_ud->write(0);

	switch (m_model)
	{
	case X9C102:
		delta = 10.0f;
		break;
	case X9C103:
		delta = 100.0f;
		break;
	case X9C104:
		delta = 1000.0f;
		break;
	case X9C503:
		delta = 500.0f;
		break;
	}

	if (InitialZero)
	{
		wPos = wPosMax;
		MoveRelative(Downward, wPosMax, false);
	}

}

void DKS::DPOT::X9Cxxx::MoveRelative(const Direction &dir, const uint8_t &stepCount, const bool &StorePos)
{
	uint8_t count;
	if (dir == Upward)
	{
		m_ud->write(1);
		if (wPosMax - wPos < stepCount)
			count = wPosMax - wPos;
		else count = stepCount;
		wPos += count;
	}
	else
	{
		m_ud->write(0);
		if (wPos < stepCount)
			count = wPos;
		else count = stepCount;
		wPos -= count;
	}

	uint8_t i;
	m_cs->write(0);
	for (i = 0; i < count; i++)
	{
		wait();
		m_inc->write(1);
		wait();
		m_inc->write(0);	//negative-edge triggered.
	}
	if (StorePos)
	{
		wait();
		m_inc->write(1);
		wait();
		m_cs->write(1);
	}
	else
	{
		wait();
		m_cs->write(1);
		wait();
		m_inc->write(1);
	}
}

void DKS::DPOT::X9Cxxx::MoveTo(const uint8_t &newPos, const bool &SavePos)
{
	uint8_t stepCount;
	if (newPos == wPos)
		return;
	else if (newPos > wPos)
	{
		stepCount = newPos - wPos;
		MoveRelative(Upward, stepCount, SavePos);
	}
	else
	{
		stepCount = wPos - newPos;
		MoveRelative(Downward, stepCount, SavePos);
	}
}

void DKS::DPOT::X9Cxxx::SetValue(const float &value)
{
	uint8_t newPos(0);
	if (value >= GetValueMax())
		newPos = wPosMax;
	else if (value <= GetValueMin())
		newPos = 0;
	else newPos = Value2wPos(value);
	MoveTo(newPos, false);
}

float DKS::DPOT::X9Cxxx::GetValue(void) const
{
	return wPos2Value(wPos);
}
float DKS::DPOT::X9Cxxx::GetValueMax(void) const
{
	return wPosMax * delta + SeriesResistance;
}
float DKS::DPOT::X9Cxxx::GetValueMin(void) const
{
	return SeriesResistance;
}

void DKS::DPOT::X9Cxxx::SetPos(const uint16_t &Pos)
{
	const uint8_t newPos = Pos >= wPosMax ? wPosMax : Pos;
	MoveTo(newPos, false);
}
uint16_t DKS::DPOT::X9Cxxx::GetPos(void) const
{
	return wPos;
}

float DKS::DPOT::X9Cxxx::wPos2Value(const uint16_t &WiperPos) const
{
	return WiperPos * delta + SeriesResistance;
}
uint16_t DKS::DPOT::X9Cxxx::Value2wPos(const float &Value) const
{
	return static_cast<uint16_t>((Value - SeriesResistance) / delta + 0.5f);
}
