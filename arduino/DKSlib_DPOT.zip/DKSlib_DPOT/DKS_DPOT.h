/*
 Copyright (c) 2017 DenshiKousakuSenka
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
 */

#pragma once

#include <DKS_Common_Base.h>
#include "DKS_GPIO_Base.h"

namespace DKS
{
	namespace DPOT
	{
		class DPOTbase
		{
		public:
			DPOTbase(void);
			virtual ~DPOTbase(void);
			virtual void SetValue(const float &value)=0;
			virtual float GetValue(void) const=0;
			virtual float GetValueMax(void)const=0;
			virtual float GetValueMin(void)const=0;

			virtual void SetPos(const uint16_t &Pos)=0;
			virtual uint16_t GetPos(void) const=0;

			virtual float wPos2Value(const uint16_t &WiperPos)const =0;		//wiper position -> resistor value
			virtual uint16_t Value2wPos(const float &Value)const =0;	// resistor value -> wiper position
		};

		enum X9CxxxModel
		{
			X9C102,	// 1k��
			X9C103,	// 10k��
			X9C503, // 50k��
			X9C104 // 100k��
		};

		enum Direction
		{
			Upward, Downward
		};

		class X9Cxxx: public DPOTbase, private Noncopyable
		{
			const X9CxxxModel m_model;
			static const uint8_t wPosMax;
			uint16_t wPos;
			volatile bool isMoving;
			DKS::IDigitalOut *m_cs, *m_inc, *m_ud;
			float delta;
			const float SeriesResistance;

			inline void wait()
			{
				for (uint8_t i = 0; i < 10; i++)
					asm("NOP");
			}
		public:
			X9Cxxx(const X9CxxxModel &Model);
			X9Cxxx(const X9CxxxModel &Model, DKS::IDigitalOut *CS, DKS::IDigitalOut *INC, DKS::IDigitalOut *UD, const bool InitialZero = true);
			virtual ~X9Cxxx(void);
			void Init(DKS::IDigitalOut *CS, DKS::IDigitalOut *INC, DKS::IDigitalOut *UD, const bool InitialZero = true);

			void MoveRelative(const Direction &dir, const uint8_t &stepCount, const bool &SavePos = true);
			void MoveTo(const uint8_t &newPos, const bool &StorePos = true);
			virtual void SetValue(const float &value);
			virtual float GetValue(void) const;
			virtual float GetValueMax(void)const;
			virtual float GetValueMin(void)const;

			virtual void SetPos(const uint16_t &Pos);
			virtual uint16_t GetPos(void) const;

			virtual float wPos2Value(const uint16_t &WiperPos) const;		//wiper position -> resistor value
			virtual uint16_t Value2wPos(const float &Value)const;	// resistor value -> wiper position
		}
		;
	}
}
